#' @importFrom magrittr %>%
#' @importFrom foreach %dopar%
utils::globalVariables(c("nancycats", "marker_name", "combination", "panel_size", "avg_success_rate"))
