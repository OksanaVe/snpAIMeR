# snpAIMeR 2.1.0

* Initial CRAN submission 2023-12-14
