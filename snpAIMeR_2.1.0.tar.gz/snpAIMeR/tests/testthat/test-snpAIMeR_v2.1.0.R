test_that("test_example_error", {
  expect_error(snpAIMeR("example"))
})
